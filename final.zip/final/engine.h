
void engine_init();
void engine_forward();
void engine_backward();
void engine_forward_slow();
void engine_turn_left();
void engine_turn_right();
void engine_rotate_left();
void engine_rotate_right();
void engine_stop();
void engine_move_to_center();
