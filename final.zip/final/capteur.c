
#include <msp430.h>
#include "ADC.h"
#include "engine.h"

void capteur_init(){

    // Entr�e du capteur d'obstacle
    P1DIR &= ~BIT4;
    // Entr�e du capteur de lumi�re
    P1DIR &= ~BIT5;

    P1DIR &=~BIT2;//ligne P2.2 en entree Capteur A
    P1DIR &=~BIT1;//ligne P2.2 en entree Capteur B

    // LED de controle
    P1DIR |= 0x41;


}

//Retourne une valeur de seuil suivant la proximit� de l'obstacle
int detect_obstacle(){

    int mesure;
    ADC_Demarrer_conversion(4); // le port P1.4 correspond au capteur IR
    mesure = ADC_Lire_resultat();
    if(mesure < 600){
        return 1; //Pas d'obstacle
    }
    else if(mesure < 700){
        return 2; //Danger
    }
    else{
        return 3; //Critique
    }

}

int detecte_lumiere()
{

    P1OUT = 0x01;
    int lum;
    int temp;
    int i;
    ADC_Demarrer_conversion(5);
    lum = ADC_Lire_resultat();
    engine_rotate_left();
    for(i = 200 ; i > 0; i--){
        ADC_Demarrer_conversion(5);
        temp = ADC_Lire_resultat();
        if(temp < lum) lum = temp;
        __delay_cycles(50000);
    }

    engine_stop();
    P1OUT &= ~0x01;
    return lum;

}

void turn_to_exit(int exit){

    P1OUT = 0x40;
    int lum;
    ADC_Demarrer_conversion(5);
    lum = ADC_Lire_resultat();
    while(lum > exit){
        engine_rotate_left();
    }
    engine_stop();
    P1OUT &= ~0x40;
}


int detecte_lum()
{

    int lum;
    ADC_Demarrer_conversion(5); // le port P1.5 correspond au capteur de lumi�re
    lum = ADC_Lire_resultat();

    return lum;
}

void lumiere()

{
    while (detecte_lum() > 250)
        {
            engine_rotate_right();
        }
    engine_stop();
    __delay_cycles(10000);
}


