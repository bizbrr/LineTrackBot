#include <msp430.h>
#include "engine.h"
#include "ADC.h"
#include "capteur.h"

unsigned int step = 0;
unsigned int exit = 0;

void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;

    engine_init();
    ADC_init();
    capteur_init();

    // Premi�re
    while(step == 0){

       switch(detect_obstacle()){
       case 1 : // Aucun Obstacle
           if(((P1IN & BIT1) !=0) && ((P1IN & BIT2) !=0)  ) //les capteurs A et B captent la ligne noir
           {
               engine_forward();//le robot avance
           }
           else if(((P1IN & BIT1) ==0) && ((P1IN & BIT2) ==0)) //les capteurs A et B captent la ligne blanche
           {
               engine_stop();

               engine_move_to_center();

               lumiere();

               engine_forward();

               __delay_cycles(10);

               engine_move_to_center();

              //SI LES CAPTEURS GAUCHE ET DROITE SONT DANS LE BLANC : arriv�e dans le cercle = STOP
           }
           else if(((P1IN & BIT1) !=0) && ((P1IN & BIT2) ==0)  ) //le capteur A  capte la ligne blanche et le B capte la ligne noire
           {

               engine_rotate_right();
              //SI LE CAPTEUR GAUCHE EST DANS LE BLANC,pivoter � gauche
          }
          else if(((P1IN & BIT1) ==0) && ((P1IN & BIT2) !=0)  ) //le capteur B  capte la ligne blanche et le A capte la ligne noire
          {

              engine_rotate_left();
              //SI LE CAPTEUR GAUCHE EST DANS LE BLANC,pivoter � gauche
          }
          break;

       case 2 : // Obstacle proche
               engine_forward_slow();
               break;

       case 3 : // Obstacle devant
               engine_stop();
               break;

       default:
               engine_rotate_left();

       }
    }


    //step = 2;
}
