
void capteur_init();
int detect_obstacle();
int detecte_lumiere();
void turn_to_exit(int exit);
void lumiere();
int detecte_lum();
