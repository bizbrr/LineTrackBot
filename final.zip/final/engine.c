
#include <msp430.h>

#define BASE_PWM 1000 /* Valeur pour le TA1CCR0 */
#define BASE_PWM_WHEEL 320 /* Valeur nominal pour les roues */
#define SLOW_PWM_WHEEL 150 /* Valeur ralentie pour les roues*/
#define TURN_PWM_WHEEL 100 /* Valeur virage pour les roues */
#define STOP_PWM_WHEEL 0 /* V9aleur arr�t pour les roues */

void engine_init(){

    // Frequence d�horloge 1MHz
    BCSCTL1= CALBC1_1MHZ;
    DCOCTL= CALDCO_1MHZ;

    // Entr�e/Sortie
    P2DIR |= (BIT1|BIT2|BIT4|BIT5);
    P2DIR &= ~(BIT0|BIT3);

    // Sens avant des roues
    P2OUT &= ~(BIT1);
    P2OUT |= BIT5;

    // Selection fonction TA
    P2SEL |= (BIT2|BIT4);
    P2SEL2 &= ~(BIT2|BIT4);

    // Source SMCLK pour TimerA , mode comptage Up
    TA1CTL = TASSEL_2 | MC_1;

    // Activation mode de sortie n�7
    TA1CCTL1 |= OUTMOD_7;
    TA1CCTL2 |= OUTMOD_7;

    // Rapport Cyclique Arr�t
    TA1CCR0 = BASE_PWM;
    TA1CCR1 = STOP_PWM_WHEEL;
    TA1CCR2 = STOP_PWM_WHEEL;

}

void engine_forward(){

    // Sens Avant des Roues
    P2OUT &= ~(BIT1);
    P2OUT |= BIT5;

    // Rapport Cyclique Nominal
    TA1CCR1 = BASE_PWM_WHEEL;
    TA1CCR2 = BASE_PWM_WHEEL;

}

void engine_backward(){

    // Sens Arri�re des Roues
    P2OUT &= ~(BIT5);
    P2OUT |= BIT1;

    // Rapport Cyclique Nominal
    TA1CCR1 = BASE_PWM_WHEEL;
    TA1CCR2 = BASE_PWM_WHEEL;

}

void engine_turn_left(){

    // Sens Avant des Roues
    P2OUT &= ~(BIT1);
    P2OUT |= BIT5;

    // Rapport Cyclique Virage Left
    TA1CCR1 = TURN_PWM_WHEEL;
    TA1CCR2 = BASE_PWM_WHEEL;

}

void engine_turn_right(){

    // Sens Avant des Roues
    P2OUT &= ~(BIT1);
    P2OUT |= BIT5;

    // Rapport Cyclique Virage Right
    TA1CCR1 = BASE_PWM_WHEEL;
    TA1CCR2 = TURN_PWM_WHEEL;

}

void engine_rotate_left(){

    // Sens Rotation Gauche des Roues
    P2OUT &= ~(BIT5|BIT1);

    // Rapport Cyclique Nominal
    TA1CCR1 = SLOW_PWM_WHEEL;
    TA1CCR2 = SLOW_PWM_WHEEL;

}

void engine_rotate_right(){

    // Sens Rotation Droite des Roues
    P2OUT |= (BIT5|BIT1);

    // Rapport Cyclique Nominal
    TA1CCR1 = SLOW_PWM_WHEEL;
    TA1CCR2 = SLOW_PWM_WHEEL;

}

void engine_stop(){

    // Sens Avant des Roues
    P2OUT &= ~(BIT1);
    P2OUT |= BIT5;

    // Rapport Cyclique Stop
    TA1CCR1 = STOP_PWM_WHEEL;
    TA1CCR2 = STOP_PWM_WHEEL;

}

void engine_forward_slow(){

    // Sens Avant des Roues
    P2OUT &= ~(BIT1);
    P2OUT |= BIT5;

    // Rapport Cyclique Stop
    TA1CCR1 = SLOW_PWM_WHEEL;
    TA1CCR2 = SLOW_PWM_WHEEL;

}

void engine_move_to_center(){

    // Placement au centre du Cercle
    engine_forward_slow();
    __delay_cycles(750000);  /* Valeur de temps pour l'arr�t au centre du cercle (SLOW_PWM_WHEEL * 5000) */
    engine_stop();

}
